-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2018 at 05:44 PM
-- Server version: 5.6.29
-- PHP Version: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `training`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookmarks`
--

CREATE TABLE IF NOT EXISTS `bookmarks` (
  `id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookmarks`
--

INSERT INTO `bookmarks` (`id`, `user_id`, `title`, `url`, `created`, `modified`) VALUES
(1, 1, 'Google', 'https://www.google.com/', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 1, 'Yahoo', 'https://www.yahoo.com/', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 2, 'Apple', 'https://www.apple.com/', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `bookmarks_tags`
--

CREATE TABLE IF NOT EXISTS `bookmarks_tags` (
  `id` int(11) NOT NULL DEFAULT '0',
  `bookmark_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bookmark_id` (`bookmark_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookmarks_tags`
--

INSERT INTO `bookmarks_tags` (`id`, `bookmark_id`, `tag_id`) VALUES
(1, 1, 1),
(2, 1, 4),
(3, 2, 5),
(4, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`, `created`, `modified`) VALUES
(1, 'technology', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'business', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'software', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'search', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'news', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'programming', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'animal', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'hardware', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'audio', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'programming', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'php', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 'cakephp', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 'advertising', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 'javascript', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 'html', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 'design', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 'research', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, 'music', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, 'videos', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(20, 'ux', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(21, 'ui', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(22, 'mobile', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL DEFAULT '0',
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `firstname`, `lastname`, `created`, `modified`) VALUES
(1, 'jane@localhost.com', '$2a$10$8a2X7OwiHv2aUk9TKL3ILeLxmlr6XQ1uWhFP45adAHpUJNNWAmwQq', 'Jane', 'Smiths', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'john@localhost.com', 'testing', 'John', 'Smith', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'robert@localhost.com', 'testing', 'Robert', 'Davis', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'mary@localhost.com', 'testing', 'Mary', 'Taylor', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookmarks`
--
ALTER TABLE `bookmarks`
  ADD CONSTRAINT `bookmarks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bookmarks_tags`
--
ALTER TABLE `bookmarks_tags`
  ADD CONSTRAINT `bookmarks_tags_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bookmarks_tags_ibfk_1` FOREIGN KEY (`bookmark_id`) REFERENCES `bookmarks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
