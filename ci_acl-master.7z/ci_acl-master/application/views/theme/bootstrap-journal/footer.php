<div class="container">
	<hr>
	<p>Copyright &copy 2012 William Duyck</p>
</div>