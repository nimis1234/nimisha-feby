-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 13, 2017 at 02:40 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `acl`
--

-- --------------------------------------------------------

--
-- Table structure for table `perm`
--

CREATE TABLE `perm` (
  `perm_id` int(11) NOT NULL,
  `name` varchar(70) NOT NULL,
  `slug` varchar(35) NOT NULL,
  `description` varchar(140) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perm`
--

INSERT INTO `perm` (`perm_id`, `name`, `slug`, `description`) VALUES
(1, 'Access ACL', 'access_acl', 'allows access to view, and change settings in, the ACL'),
(2, 'Add User', 'add_user', 'gives ability to add users'),
(3, 'Add Role', 'add_role', 'gives ability to add roles to the system'),
(4, 'Add Permissions', 'add_perm', 'gives the ability to add new permissions to the system'),
(5, 'Assign Role', 'assign_role', 'ability to assign roles to users'),
(6, 'Edit User', 'edit_user', 'gives the ability to edit users personal details'),
(7, 'Delete User', 'delete_user', 'ability to delete a user from the system'),
(8, 'View Users', 'view_users', 'ability to view user details (inc. personal details)'),
(9, 'Edit Permission', 'edit_perm', 'ability to edit permissions'),
(10, 'Edit Role', 'edit_role', 'ability to edit roles'),
(11, 'Delete Permission', 'delete_perm', 'ability to delete permissions from the system'),
(12, 'Delete Role', 'delete_role', 'ability to delete roles'),
(13, 'View Permissions', 'view_perms', 'view available permissions'),
(14, 'View Roles', 'view_roles', 'ability to view available roles');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL,
  `name` varchar(70) NOT NULL,
  `slug` varchar(35) NOT NULL,
  `description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`role_id`, `name`, `slug`, `description`) VALUES
(1, 'Developer', 'developer', 'this is someone who maintains the system\'s database, codebase, etc...'),
(2, 'Administrator', 'admin', 'this is someone who manages the system from the ui. they have access to the acl, user details, and more...');

-- --------------------------------------------------------

--
-- Table structure for table `role_perm`
--

CREATE TABLE `role_perm` (
  `role_id` int(11) NOT NULL,
  `perm_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role_perm`
--

INSERT INTO `role_perm` (`role_id`, `perm_id`) VALUES
(1, 1),
(1, 4),
(1, 9),
(1, 11),
(1, 13),
(1, 14),
(2, 1),
(2, 2),
(2, 3),
(2, 5),
(2, 6),
(2, 7),
(2, 8),
(2, 10),
(2, 13),
(2, 14);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `name` varchar(70) NOT NULL,
  `email` varchar(254) NOT NULL,
  `password` char(128) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `email`, `password`) VALUES
(1, 'Demo Account', 'demo@example.com', 'b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb980b1d7785e5976ec049b46df5f1326af5a2ea6d103fd07c95385ffab0cacbc86'),
(2, 'nidheesh', 'nidheesh43@gmail.com', '2f531a3e9911cd186ba4238dd36452fa00640f57e641229904ba4e119bda700a5bddf5f42f2352b26fc03c983748d496471abc14f51037d4e996ba24267941e0'),
(3, 'Aby paul', 'abypaul23@mail.com', '7e841226fb9bd83df989db89940685c492260d93126361317f95d65e0c63ad0f31ff2b7adce6dcb5f6891d3fe7339f5fe5a19e11a21fd3e176c136a577bd0f3d');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`user_id`, `role_id`) VALUES
(1, 1),
(1, 2),
(2, 2),
(3, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `perm`
--
ALTER TABLE `perm`
  ADD PRIMARY KEY (`perm_id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `role_perm`
--
ALTER TABLE `role_perm`
  ADD PRIMARY KEY (`role_id`,`perm_id`),
  ADD KEY `perm_id` (`perm_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `role_id` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `perm`
--
ALTER TABLE `perm`
  MODIFY `perm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
