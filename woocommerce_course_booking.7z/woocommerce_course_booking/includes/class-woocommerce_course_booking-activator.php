<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.iteverywhere.co.uk/
 * @since      1.0.0
 *
 * @package    Woocommerce_course_booking
 * @subpackage Woocommerce_course_booking/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Woocommerce_course_booking
 * @subpackage Woocommerce_course_booking/includes
 * @author     IT Everywhere Ltd <info@iteverywhere.co.uk >
 */
class Woocommerce_course_booking_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
