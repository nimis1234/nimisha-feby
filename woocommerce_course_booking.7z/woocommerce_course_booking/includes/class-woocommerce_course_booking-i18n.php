<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://www.iteverywhere.co.uk/
 * @since      1.0.0
 *
 * @package    Woocommerce_course_booking
 * @subpackage Woocommerce_course_booking/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Woocommerce_course_booking
 * @subpackage Woocommerce_course_booking/includes
 * @author     IT Everywhere Ltd <info@iteverywhere.co.uk >
 */
class Woocommerce_course_booking_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'woocommerce_course_booking',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
