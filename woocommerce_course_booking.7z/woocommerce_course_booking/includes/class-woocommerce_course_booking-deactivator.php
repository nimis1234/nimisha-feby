<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://www.iteverywhere.co.uk/
 * @since      1.0.0
 *
 * @package    Woocommerce_course_booking
 * @subpackage Woocommerce_course_booking/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Woocommerce_course_booking
 * @subpackage Woocommerce_course_booking/includes
 * @author     IT Everywhere Ltd <info@iteverywhere.co.uk >
 */
class Woocommerce_course_booking_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
